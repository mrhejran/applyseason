<?php switch(config("blogetc.comments.type_of_comments_to_show","built_in")):

case ("built_in"): ?>

<?php echo $__env->make("blogetc::partials.built_in_comments", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make("blogetc::partials.add_comment_form", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php break; ?>

<?php case ("disqus"): ?>

<?php echo $__env->make("blogetc::partials.disqus_comments", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php break; ?>


<?php case ("custom"): ?>

<?php echo $__env->make("blogetc::partials.custom_comments", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php break; ?>

<?php case ("disabled"): ?>

<?php
return;  // not required, as we already filter for this
?>
<?php break; ?>

<?php default: ?>

<div class='alert alert-danger'>Invalid comment <code>type_of_comments_to_show</code> config option</div>";
<?php endswitch; ?>


