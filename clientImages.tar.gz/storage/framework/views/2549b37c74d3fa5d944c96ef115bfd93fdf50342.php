<?php $__env->startSection("content"); ?>

    

    <div class='row'>
        <div class='col-sm-12 blogetc_container'>
            <?php if(\Auth::check() && \Auth::user()->canManageBlogEtcPosts()): ?>
                <div class="text-center">
                        <p class='mb-1'>You are logged in as a blog admin user.
                            <br>

                            <a href='<?php echo e(route("blogetc.admin.index")); ?>'
                               class='btn border  btn-outline-primary btn-sm '>

                                <i class="fa fa-cogs" aria-hidden="true"></i>

                                Go To Blog Admin Panel</a>


                        </p>
                </div>
            <?php endif; ?>


            <?php if(isset($blogetc_category) && $blogetc_category): ?>
                <h2 class='text-center'>Viewing Category: <?php echo e($blogetc_category->category_name); ?></h2>

                <?php if($blogetc_category->category_description): ?>
                    <p class='text-center'><?php echo e($blogetc_category->category_description); ?></p>
                <?php endif; ?>

            <?php endif; ?>


            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php echo $__env->make("blogetc::partials.index_loop", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class='alert alert-danger'>No posts</div>
            <?php endif; ?>

            <div class='text-center  col-sm-4 mx-auto'>
                <?php echo e($posts->appends( [] )->links()); ?>

            </div>




                <?php echo $__env->make("blogetc::sitewide.search_form", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app",['title'=>$title], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>