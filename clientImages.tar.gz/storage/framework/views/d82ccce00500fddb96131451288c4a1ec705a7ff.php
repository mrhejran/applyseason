<?php if(\Auth::check() && \Auth::user()->canManageBlogEtcPosts()): ?>
    <a href="<?php echo e($post->edit_url()); ?>" class="btn btn-outline-secondary btn-sm pull-right float-right">Edit
        Post</a>
<?php endif; ?>

<h2 class='blog_title'><?php echo e($post->title); ?></h2>
<h5 class='blog_subtitle'><?php echo e($post->subtitle); ?></h5>


<?=$post->image_tag("medium", false, 'd-block mx-auto'); ?>

<p class="blog_body_content">
    <?php echo $post->post_body_output(); ?>


    
    
    
    
    
    
    
</p>

<hr/>

Posted <strong><?php echo e($post->posted_at->diffForHumans()); ?></strong>

<?php echo $__env->renderWhen($post->author,"blogetc::partials.author",['post'=>$post], array_except(get_defined_vars(), array('__data', '__path'))); ?>
<?php echo $__env->renderWhen($post->categories,"blogetc::partials.categories",['post'=>$post], array_except(get_defined_vars(), array('__data', '__path'))); ?>
