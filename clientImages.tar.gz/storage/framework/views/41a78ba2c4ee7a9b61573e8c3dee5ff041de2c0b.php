<!DOCTYPE html>
<html lang="en">
  <?php echo $__env->make('include.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <body>
    
    <?php echo $__env->make('include.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- END nav -->
    
    <div class="hero-wrap js-fullheight" style="background-image: url('user_assets/images/bg_2.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start" data-scrollax-parent="true">
          <div class="col-md-8 ftco-animate text-center text-md-left mb-5" data-scrollax=" properties: { translateY: '70%' }">
          	<p class="breadcrumbs" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><span class="mr-3"><a href="index.html">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Blog</span></p>
            <h1 class="mb-3 bread" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Blog</h1>
          </div>
        </div>
      </div>
    </div>

    <section class="ftco-section bg-light">
      <div class="container">
        <div class="row ">



<!-- <?php $__currentLoopData = $Block_Blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


			<div class="col-md-4">
				
						<img src="<?php echo e(asset('blog_images/'.$Blog->image_thumbnail)); ?>" style="height: 220px;width: 100%;border-radius: 10px;">
						<a href="#"><?php echo e($Blog->DATE_BLOG); ?></a>
						<a href="#">Admin</a>
						<h3><a href="<?php echo e(url('/ViewBlog/'.$Blog->B_URL)); ?>"><?php echo e($Blog->title); ?></a></h3>
						<p><?php echo str_limit($Blog->post_body,140); ?>

					
			</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
<?php $__empty_1 = true; $__currentLoopData = $Block_Blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class='col-md-4'> 

				<!-- <a href="<?php echo e($post->url()); ?>"> -->
				<a href="<?php echo e($post->path()); ?>"><img src="<?php echo e(asset('blog_images/'.$post->image_thumbnail)); ?>" 
				style="height: 220px;width: 100%;border-radius: 10px;padding-bottom:20px"></a>
				<!-- </a> -->
        <span class=''><?php echo e(date('d-M-Y', strtotime($post->posted_at))); ?> </span>
        <span style="padding-right:10px;float:right"><?php echo e($post->author->name); ?></span><hr>
                <h3 class=''><a href="<?php echo e($post->path()); ?>"><?php echo e($post->title); ?></a></h3>
				
                <p><?php echo $post->generate_introduction(140); ?></p>
                <!-- <a href="<?php echo e($post->url()); ?>" class="btn btn-info">View Post</a> -->
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            no post
        <?php endif; ?>

		<div class="block-27">
			<?php echo e($Block_Blog->links()); ?>

		</div>

        </div>
      </div>
    </section>
		
	 <?php echo $__env->make('include.subscribe', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<style>
	.block-27 ul li a, .block-27 ul li span {
		display: inline-block;
		width: 40px;
		height: 40px;
		line-height: 25px;
	}
</style>
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <?php echo $__env->make('include.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
  </body>
</html>
