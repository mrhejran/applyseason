

<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript">
		$("#example1").DataTable();
	</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
	<script src="<?php echo e(asset('public/js/tinymce.min.js')); ?>" referrerpolicy="origin"></script>
	<script>tinymce.init({selector:'textarea'});</script>
	<style>
		.tox-tinymce-aux {
			display: none;
		}
	</style>
	<section class="content">
		<div class="container-fluid">
			<div class="invoice p-3 mb-3">
				<div class="row">
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-6">
								<h3>Home Page Setting</h3>
							</div>
						</div>

						<br />
						<?php if($message = Session::get('success')): ?>
							<div class="alert alert-success alert-block">
								<button type="button" class="close" data-dismiss="alert">×</button>
								<strong><?php echo e($message); ?></strong>
							</div>
						<?php endif; ?>
						<div class="panel panel-default">
							<div class="panel-heading">

							</div>
							<div class="panel-body">
								<?php
									$Block_Data=\App\Model\HomePage::whereid('1')->get();

								?>
								<?php $__currentLoopData = $Block_Data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="row">
										<div class="col-md-12">
											<p>Site Setting</p>
										</div>
										<div class="col-md-6">
											<form action="<?php echo e(url('update_home_content')); ?>" method="post" enctype="multipart/form-data">
												<?php echo e(csrf_field()); ?>

												<div class="form-group">
													<label><small>Page Title</small></label>
													<input type="text" class="form-control" name="pagetitle" value="<?php echo e($block->page_title); ?>">
												</div>

												<div class="form-group">
													<label><small>Site Title</small></label>
													<input type="text" class="form-control" name="sitetitle" value="<?php echo e($block->slide_logo); ?>">
												</div>

												<div class="form-group">
													<label><small>Slide Title</small></label>
													<input type="text" class="form-control" name="slidetitle" value="<?php echo e($block->slide_title); ?>">
												</div>

												<div class="form-group">
													<label><small>About Description</small></label>
													<textarea class="" name="aboutdes" rows="5"><?php echo e($block->slide_about); ?></textarea>
												</div>

												<div class="form-group">
													<label><small>Subcribe Description</small></label>
													<textarea class="" name="subcribdes" rows="5"><?php echo e($block->slide_subscrib); ?></textarea>
												</div>
												<div class="form-group">
													<label><small>Slide Image</small></label>
													<input type="file" class="form-control" name="image_section">
												</div>

												<div class="form-group">
													<button type="submit" class="btn btn-primary">Update</button>
												</div>
											</form>
										</div>
										<div class="col-md-6">
											<div>
												<img src="<?php echo e(asset('public/page_content/'.$block->slide_imge)); ?>" class="img-fluid" >
											</div>
										</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
							</div>


							<hr>

							<div class="panel-body">


								<div class="row">
									<div class="col-md-6">
										<p>Counter Setting </p>

									</div>

									<div class="col-md-6 text-right">

									</div>Counter
									<div class="col-md-12">
<?php
	$Block_Counter=\App\Model\Counter::whereid('1')->get();

?>
<?php $__currentLoopData = $Block_Counter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Counter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<form action="<?php echo e(url('update_counter')); ?>" method="post" enctype="multipart/form-data">
											<?php echo e(csrf_field()); ?>


											<div class="row">
												<div class="col-md-3">
													<div class="form-group">
														<label><small>Jobs</small></label>
														<input type="text" class="form-control" name="jobs" value="<?php echo e($Counter->cout_Jobs); ?>" >
													</div>
												</div>
												<div class="col-md-3">
													<div class="form-group">
														<label><small>Members</small></label>
														<input type="text" class="form-control" name="members"  value="<?php echo e($Counter->cout_Members); ?>">
													</div>
												</div>
												<div class="col-md-3">
													<div class="form-group">
														<label><small>Resume</small></label>
														<input type="text" class="form-control" name="resume"  value="<?php echo e($Counter->cout_Resume); ?>">
													</div>
												</div>
												<div class="col-md-3">
													<div class="form-group">
														<label><small>Company</small></label>
														<input type="text" class="form-control" name="company"  value="<?php echo e($Counter->cout_Company); ?>">
													</div>
												</div>
												<div class="col-md-12">
													<div class="form-group">
														<button type="submit" class="btn btn-primary">Update</button>
													</div>
												</div>
											</div>
										</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>

								</div>
							</div>
						</div>
					</div>
				</div>
			</div><!-- /.container-fluid -->
	</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>