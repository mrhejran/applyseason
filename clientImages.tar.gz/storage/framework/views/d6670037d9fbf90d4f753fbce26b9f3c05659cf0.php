<head>
<?php
	$Block_Data3=\App\Model\HomePage::whereid('1')->get();

?>
<?php $__currentLoopData = $Block_Data3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <title><?php echo e($block3->page_title); ?></title>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:200,300,400,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('user_assets/css/open-iconic-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user_assets/css/animate.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('user_assets/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user_assets/css/owl.theme.default.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user_assets/css/magnific-popup.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('user_assets/css/aos.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('user_assets/css/ionicons.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('user_assets/css/bootstrap-datepicker.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user_assets/css/jquery.timepicker.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('user_assets/css/flaticon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user_assets/css/icomoon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user_assets/css/style.css')); ?>">
	
    <link rel="stylesheet" href="<?php echo e(asset('user_assets/css/newStyle.css')); ?>">


    <link rel="stylesheet" href="<?php echo e(asset('user_assets/css/feature-text.css')); ?>">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" href="">
  </head>
<?php /**PATH /home/applysea/domains/applyseason.com/public_html/resources/views/include/head.blade.php ENDPATH**/ ?>