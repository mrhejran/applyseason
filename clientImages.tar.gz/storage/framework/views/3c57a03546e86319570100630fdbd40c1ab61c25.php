<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
    <div class="container">
<?php
	$Block_Data2=\App\Model\HomePage::whereid('1')->get();

?>
<?php $__currentLoopData = $Block_Data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><?php echo e($block2->slide_logo); ?></a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="oi oi-menu"></span> Menu
      </button>

      <div class="collapse navbar-collapse" id="ftco-nav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item <?php if(\Route::current()->getName() == '/'): ?> active <?php endif; ?>"><a href="<?php echo e(route('/')); ?>" class="nav-link">Home</a></li>
          <li class="nav-item <?php if(\Route::current()->getName() == 'about'): ?> active <?php endif; ?>"><a href="<?php echo e(route('about')); ?>" class="nav-link">About</a></li>
          <li class="nav-item <?php if(\Route::current()->getName() == 'blogs'): ?> active <?php endif; ?>"><a href="<?php echo e(route('blogs')); ?>" class="nav-link">Blog</a></li>
          <li class="nav-item <?php if(\Route::current()->getName() == 'contact'): ?> active <?php endif; ?>"><a href="<?php echo e(route('contact')); ?>" class="nav-link">Contact</a></li>
          <li class="nav-item cta mr-md-2"><a href="<?php echo e(route('new-post')); ?>" class="nav-link">Post a Job</a></li>
          <li class="nav-item cta cta-colored"><a href="<?php echo e(route('job-post')); ?>" class="nav-link">Want a Job</a></li>

        </ul>
      </div>
    </div>
  </nav>