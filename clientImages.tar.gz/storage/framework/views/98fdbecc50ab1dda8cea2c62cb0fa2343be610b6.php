<?php $__env->startSection("content"); ?>


    

    <div class='container'>
    <div class='row'>
        <div class='col-sm-12 col-md-12 col-lg-12'>

            <?php echo $__env->make("blogetc::partials.show_errors", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make("blogetc::partials.full_post_details", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


            <?php if(config("blogetc.comments.type_of_comments_to_show","built_in") !== 'disabled'): ?>
                <div class="" id='maincommentscontainer'>
                    <h2 class='text-center' id='blogetccomments'>Comments</h2>
                    <?php echo $__env->make("blogetc::partials.show_comments", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            <?php else: ?>
                
            <?php endif; ?>


        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app",['title'=>$post->gen_seo_title()], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>