<footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-5">
        	<div class="col-md">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">About</h2>
 <?php
	 $Block_Data4=\App\Model\HomePage::whereid('1')->get();

 ?>
 <?php $__currentLoopData = $Block_Data4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block4): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					 <p><?php echo $block4->slide_about ?></p>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-3">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Employers</h2>
              <ul class="list-unstyled">
                <li><a href="#" class="py-2 d-block">How it works</a></li>
                <li><a href="#" class="py-2 d-block">Register</a></li>
                <li><a href="#" class="py-2 d-block">Post a Job</a></li>
                <li><a href="#" class="py-2 d-block">Advance Skill Search</a></li>
                <li><a href="#" class="py-2 d-block">Recruiting Service</a></li>
                <li><a href="#" class="py-2 d-block">Blog</a></li>
                <li><a href="#" class="py-2 d-block">Faq</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4 ml-md-4">
              <h2 class="ftco-heading-2">Workers</h2>
              <ul class="list-unstyled">
                <li><a href="#" class="py-2 d-block">How it works</a></li>
                <li><a href="#" class="py-2 d-block">Register</a></li>
                <li><a href="#" class="py-2 d-block">Post Your Skills</a></li>
                <li><a href="#" class="py-2 d-block">Job Search</a></li>
                <li><a href="#" class="py-2 d-block">Emploer Search</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2">Have a Questions?</h2>
            	<div class="block-23 mb-3">
	              <ul>
<?php
  $Block_Contact=\App\Model\Contact_info::whereid(1)->get();

?>
<?php
$count = 1;
foreach($Block_Contact as $Contact_Block):
						  //'address', 'contact_no', 'email', 'website_link', 'map_location'
  ?>
	                <li><span class="icon icon-map-marker"></span><span class="text"><?php echo e($Contact_Block->address); ?></span></li>
	                <li><a href="#"><span class="icon icon-phone"></span><span class="text"><?php echo e($Contact_Block->contact_no); ?></span></a></li>
	                <li><a href="#"><span class="icon icon-envelope"></span><span class="text"><?php echo e($Contact_Block->email); ?></span></a></li>
<?php
$count++;
endforeach;
?>
	              </ul>
	            </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Develop by  <a href="http://mksoltech.com" target="_blank">MKSOL TECH</a>
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
          </div>
        </div>
      </div>
    </footer><?php /**PATH /home/applysea/domains/applyseason.com/public_html/resources/views/include/footer.blade.php ENDPATH**/ ?>