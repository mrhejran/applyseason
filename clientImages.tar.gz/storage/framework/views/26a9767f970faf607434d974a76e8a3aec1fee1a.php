<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript">
		$("#example1").DataTable();
	</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

	<section class="content">
		<div class="container-fluid">
			<div class="invoice p-3 mb-3">
				<div class="row">
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-6">
								<h3>Blogs List</h3>
							</div>
							<div class="col-md-6 text-right">
								<a href="<?php echo e(url('Create_blog')); ?>" class="btn btn-primary btn-sm">Create Blog</a>
							</div>
						</div>

						<br />
						<?php if($message = Session::get('success')): ?>
							<div class="alert alert-success alert-block">
								<button type="button" class="close" data-dismiss="alert">×</button>
								<strong><?php echo e($message); ?></strong>
							</div>
						<?php endif; ?>
						<div class="panel panel-default">
							<div class="panel-heading">

							</div>
							<div class="panel-body">
								<div class="table-responsive">
									<table id="example1" class="table table-bordered table-striped">
										<thead>
										<tr>
											<th>Sr No</th>
											<th>Image</th>
											<th>Title</th>
											<th>Date</th>
											<th>Action</th>
										</tr>
										</thead>
										<tbody>
										<?php
										$count = 1;
										foreach($blog_data as $row):
												////SELECT `ID`, `TITLE`, `DATE_BLOG`, `AUTH_BLOG`, `DEC_BLOG`, `IMG_BLOG`, `STATUS_BLOG` FROM `blog` WHERE 1
										?>
										<tr>
											<td><?php echo e($count); ?></td>
											<td> <img src="<?php echo e(asset('public/blogImages/'.$row->IMG_BLOG)); ?>" style="height: 70px;"></td>
											<td><?php echo e($row->TITLE); ?></td>
											<td><?php echo e($row->DATE_BLOG); ?></td>
											<td>
												<a href="<?php echo e(url('Edit_Blog/'.$row->ID)); ?>" class="btn btn-primary"><small class="text-white">Edit</small></a>
												<a href="<?php echo e(url('Delete_Blog/'.$row->ID)); ?>" class="btn btn-danger"><small class="text-white">Delete</small></a>
											</td>

										</tr>
										<?php
										$count++;
										endforeach;
										?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div><!-- /.container-fluid -->
	</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/applysea/domains/applyseason.com/public_html/resources/views/admin/blog/blog_list.blade.php ENDPATH**/ ?>