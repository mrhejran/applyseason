<?php $__env->startSection("content"); ?>


    <h5>Admin - Edit Category</h5>

    <form method='post' action='<?php echo e(route("blogetc.admin.categories.edit_category",$category->id)); ?>'  enctype="multipart/form-data" >

        <?php echo csrf_field(); ?>
        <?php echo method_field("patch"); ?>
        <?php echo $__env->make("blogetc_admin::categories.form", ['category' => $category], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <input type='submit' class='btn btn-primary' value='Save Changes' >

    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("blogetc_admin::layouts.admin_layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>