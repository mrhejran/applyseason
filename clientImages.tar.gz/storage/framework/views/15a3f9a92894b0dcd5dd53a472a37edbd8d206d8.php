<section class="ftco-section-parallax">
      <div class="parallax-img d-flex align-items-center">
        <div class="container">
          <div class="row d-flex justify-content-center">
            <div class="col-md-7 text-center heading-section heading-section-white ftco-animate">
              <h2>Subcribe to our Newsletter</h2>
<?php
	$Block_Data5=\App\Model\HomePage::whereid('1')->get();

?>
<?php $__currentLoopData = $Block_Data5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block5): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<p><?php echo $block5->slide_subscrib ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <div class="row d-flex justify-content-center mt-4 mb-4">
                <div class="col-md-8">
                  <form action="#" class="subscribe-form">
                    <div class="form-group d-flex">
                      <input type="text" class="form-control" placeholder="Enter email address">
                      <input type="submit" value="Subscribe" class="submit px-3">
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section><?php /**PATH /home/applysea/domains/applyseason.com/public_html/resources/views/include/subscribe.blade.php ENDPATH**/ ?>