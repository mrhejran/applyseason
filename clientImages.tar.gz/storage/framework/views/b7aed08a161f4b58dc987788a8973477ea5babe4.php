by <strong><?php echo e($post->author->name); ?></strong>
