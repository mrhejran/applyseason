<?php $__env->startSection("content"); ?>


    <h5>Admin - Add post</h5>
    <?php $__empty_1 = true; $__currentLoopData = $Block_Blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

				Permalink: <a href="<?php echo e($post->path()); ?>"><?php echo e($post->path()); ?></a>
			
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            no post
        <?php endif; ?>
    <form method='post' action='<?php echo e(route("blogetc.admin.store_post")); ?>'  enctype="multipart/form-data" >

        <?php echo csrf_field(); ?>
        <?php echo $__env->make("blogetc_admin::posts.form", ['post' => new \WebDevEtc\BlogEtc\Models\BlogEtcPost()], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <input type='submit' class='btn btn-primary' value='Add new post' >

    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("blogetc_admin::layouts.admin_layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>