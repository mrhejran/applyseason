



<div class="" style='max-width:600px; margin: 50px auto; background: #fffbea;border-radius:3px;padding:0;' >

    <div class='text-center'>
    <?=$post->image_tag("medium", true, ''); ?>
        </div>
    <div style='padding:10px;'>
    <h3 class=''><a href='<?php echo e($post->url()); ?>'><?php echo e($post->title); ?></a></h3>
    <h5 class=''><?php echo e($post->subtitle); ?></h5>

    <p><?php echo $post->generate_introduction(400); ?></p>

    <div class='text-center'>
        <a href="<?php echo e($post->url()); ?>" class="btn btn-primary">View Post</a>
    </div>
        </div>
</div>
